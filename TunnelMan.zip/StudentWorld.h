#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Actor.h"
#include "GameConstants.h"
#include <string>
#include <vector>
#include <cmath>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir) : GameWorld(assetDir) {}

	~StudentWorld() {}

	virtual int init()
	{
		srand(time(0));

		int oilMin = 2 + getLevel();
		levelOil = std::min(oilMin, 21);

		int goldMin = 5 - getLevel() / 2;
		levelGold = std::max(goldMin, 2);
		fieldGold = levelGold;

		int itemMax = 300 - 10 * getLevel();
		itemLife = std::max(100, itemMax);

		int protMax = 3 - getLevel() / 4;
		ticksToWaitBetweenMoves = std::max(0, protMax);

		int stunMax = 100 - getLevel() * 10;
		stunTick = std::max(50, stunMax);

		int protS_Max = 200 - getLevel();
		p_spawn_target = std::max(25, protS_Max);

		int mp_Max = 2 + getLevel() * 1.5;
		maxP = std::min(15, mp_Max);

		int hprotMax = getLevel() * 10 + 30;
		roll_h = std::min(90, hprotMax);

		int stareMax = 100 - getLevel() * 10;
		stareTick = std::max(50, stareMax);

		remainingWater = 5;
		tSonar = 1;
		tGold = 0;

		m_tman = new TunnelMan(this, 30, 60);
		
		earthGen();
		boulderGen();
		oilGen();
		goldGen();

		int AI_roll = rand() % roll_h;
		//m_actors.push_back(new H_Protester(this, 60, 60));
		///*
		if (AI_roll == 5) {
			m_actors.push_back(new HardcoreProtester(this, 60, 60));
			fieldProt++;
		}
		else {
			m_actors.push_back(new RegularProtester(this, 60, 60));
			fieldProt++;
		}
		//*/
		/*//Distance Calc
		double x1 = m_actors[0]->getX();
		double x2 = m_actors[1]->getX();

		double y1 = m_actors[0]->getY();
		double y2 = m_actors[1]->getY();

		std::cout << sqrt((pow(x2 - x1, 2.0) + pow(y2 - y1, 2.0))) << std::endl;
		*///////
		
		for (int i = 0; i < m_actors.size(); i++) {
			if (m_actors[i]->getID() == TID_BOULDER) {
				cleanBoulders(m_earth, m_actors[i]);
			}
		}
		//std::cout << m_actors.size() << std::endl;

		//std::cout << "ADD HARDCORE PROTESTER\n";
		//std::cout << "ADD HARDCORE PROTESTER CHASE BEHAVIOR\n";
		
		return GWSTATUS_CONTINUE_GAME;
	}

	virtual int move()
	{
		tickCount++;
		
		p_spawnTick++;

		m_tman->doSomething();

		dig_collisionCheck(*m_tman, m_earth);

		for (int i = 0; i < m_actors.size(); i++) {
			m_actors[i]->doSomething();
		}
		//srand(time(0));
		int goodieRoll = rand() % (getLevel() * 25 + 300);
		
		if (goodieRoll == 100) {
			int itemRoll = rand() % 5;
			if (itemRoll == 4) {
				if (fieldSonar == 0) {
					if (sqrt((pow(m_tman->getX() - 0, 2.0) + pow(m_tman->getY() - 60, 2.0))) > 6) {
						m_actors.push_back(new SonarKit(this, 0, 60, tickCount));
						fieldSonar++;
					}
				}
			}
			else {
				spawn_pool();
			}
		}

		if (p_spawnTick == p_spawn_target) {
			if (fieldProt < maxP) {
				int AI_roll = rand() % roll_h;

				if (AI_roll == 5) {
					m_actors.push_back(new HardcoreProtester(this, 60, 60));
					fieldProt++;
				}
				else {
					m_actors.push_back(new RegularProtester(this, 60, 60));
					fieldProt++;
				}
			}
		}

		setDisplayText();

		if (m_tman->hp < 1) {
			decLives();
			if (kia) {
				playSound(SOUND_PLAYER_GIVE_UP);
			}
			return GWSTATUS_PLAYER_DIED;
		}

		if (levelOil == 0) {
			return GWSTATUS_FINISHED_LEVEL;
		}

		checkForDead();

		return GWSTATUS_CONTINUE_GAME;
	}

	virtual void cleanUp()
	{
		if (m_tman != nullptr) {
			delete m_tman;
		}

		for (int i = 0; i < 64; i++) {
			for (int j = 0; j < 64; j++) {
				if (m_earth[i][j] != nullptr) {
				delete[] m_earth[i][j];
				}
			}
		}
		
		for (int i = 0; i < m_actors.size(); i++) {
			delete m_actors[i];
			m_actors[i] = nullptr;
		}
		
		m_actors.clear();
		
	}

	void boulderGen();

	void earthGen();

	void oilGen();

	void goldGen();

	void setDisplayText();

	void dig_collisionCheck(TunnelMan& m_tman, Earth* m_earth[64][64]);

	void cleanBoulders(Earth* m_earth[64][64], baseClass*& m_boulder);

	std::vector<baseClass*> getActors();

	void checkForDead();

	TunnelMan* getMan();
	
	bool okDrop(baseClass* m_boulder);

	bool water_collision(baseClass* squirt);

	void spawnSquirt(int spawnX, int spawnY);

	void spawn_tGold(int spawnX, int spawnY);

	//void rspawn_gold();

	void spawn_pool();

	int goodie_collision(baseClass* gold);

	void activateSonar();

	bool p_moveCheck(baseClass* prot, baseClass::Direction dir);

	bool leaveCheck(int x, int y, baseClass::Direction dir);

	baseClass::Direction p_LoS(baseClass* prot);
	
	int tickCount = 0;

	int ticksToWaitBetweenMoves = 0;

	//player squirt count
	int remainingWater = 0;

	//gold on the field
	int fieldGold = 0;

	//player gold
	int tGold = 0;

	//total amount of oil in the current level
	int levelOil = 0;

	//amount of gold that should be in levels
	int levelGold = 0;

	//lifetime of the sonar on the screen
	int itemLife = 0;

	//sonar on the field
	int fieldSonar = 0;

	//player sonar count
	int tSonar = 0;

	int fieldProt = 0;

	//if the player was killed by a protester/boulder
	bool kia = false;

	int stunTick = 0;

	int stareTick = 0;

	int p_spawnTick = 0;

	int maxP = 0;

	int roll_h = 0;

	int p_spawn_target = 0;

private:
	TunnelMan* m_tman = nullptr;
	Earth* m_earth[64][64];
	std::vector<baseClass*> m_actors;
};

#endif // STUDENTWORLD_H_
