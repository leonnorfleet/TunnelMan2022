#include "Actor.h"
#include "StudentWorld.h"

using namespace std;

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

StudentWorld* baseClass::getWorld() {
	return m_sw;
}

bool baseClass::alive() const {
	return isAlive;
}

void baseClass::setDead() {
	isAlive = false;
}

void baseClass::annoy(int val) {
	if (hp - val <= 0) {
		hp = 0;
	}
	else {
		hp -= val;
	}
}

void TunnelMan::doSomething() {
	//switch case using getworld to read input and move accordingly
	//checks for out of bounds movement and performs calls to studentworld to check if there are boulders in the path before moving with checkDir
	if (!alive()) {
		return;
	}

	int ch;

	if (getWorld()->getKey(ch) == true) {
		switch (ch)
		{
		case KEY_PRESS_LEFT:
			if (getDirection() != left) {
				setDirection(left);
			}
			else {
				if (getX() - 1 >= 0) {
					if (checkDir(ch)) {
						moveTo(getX() - 1, getY());
					}
				}
			}
			break;
		case KEY_PRESS_RIGHT:
			if (getDirection() != right) {
				setDirection(right);
			}
			else {
				if (getX() + 1 <= 60) {
					if (checkDir(ch)) {
						moveTo(getX() + 1, getY());
					}
				}
			}
			break;
		case KEY_PRESS_UP:
			if (getDirection() != up) {
				setDirection(up);
			}
			else {
				if (getY() + 1 <= 60) {
					if (checkDir(ch)) {
						moveTo(getX(), getY() + 1);
					}
				}
			}
			break;
		case KEY_PRESS_DOWN:
			if (getDirection() != down) {
				setDirection(down);
			}
			else {
				if (getY() - 1 >= 0) {
					if (checkDir(ch)) {
						moveTo(getX(), getY() - 1);
					}
				}
			}
			break;
		case KEY_PRESS_SPACE:
			if (getWorld()->remainingWater > 0) {
				switch (getDirection())
				{
				case left:
					getWorld()->remainingWater--;
					getWorld()->spawnSquirt(getX() - 3, getY());
					getWorld()->playSound(SOUND_PLAYER_SQUIRT);
					break;
				case right:
					getWorld()->remainingWater--;
					getWorld()->spawnSquirt(getX() + 3, getY());
					getWorld()->playSound(SOUND_PLAYER_SQUIRT);
					break;
				case up:
					getWorld()->remainingWater--;
					getWorld()->spawnSquirt(getX(), getY() + 3);
					getWorld()->playSound(SOUND_PLAYER_SQUIRT);
					break;
				case down:
					getWorld()->remainingWater--;
					getWorld()->spawnSquirt(getX(), getY() - 3);
					getWorld()->playSound(SOUND_PLAYER_SQUIRT);
					break;
				default:
					return;
					break;
				}
			}
			break;
		case KEY_PRESS_ESCAPE:
			hp = 0;
			break;
		case KEY_PRESS_TAB:
			if (getWorld()->tGold > 0) {
				getWorld()->spawn_tGold(getX(), getY());
				getWorld()->tGold--;
			}
			break;
		case 'z':
		case 'Z':
			if (getWorld()->tSonar > 0) {
				getWorld()->activateSonar();
				getWorld()->tSonar--;
				//getWorld()->playSound(SOUND_SONAR);
			}
			break;
		default:
			return;
			break;
		}
	}


}

bool TunnelMan::checkDir(int direction) {
	//use getworld to access the vector of actors and search for boulders, then if the boulder's 4x4 will overlap with tunnelman's 4x4 return false
	//otherwise this function clears tunnelman to move in the direction indicated by the key
	bool canMove = true;
	switch (direction) {
	case KEY_PRESS_LEFT:
		for (int i = 0; i < getWorld()->getActors().size(); i++) {
			if (getWorld()->getActors()[i]->getID() == TID_BOULDER && getWorld()->getActors()[i]->isVisible()) {
				for (int j = 0; j < 4; j++) {
					for (int k = 0; k < 4; k++) {
						if (getX() == getWorld()->getActors()[i]->getX() + 4 && getY() + j == getWorld()->getActors()[i]->getY() + k) {
							canMove = false;
						}
					}
				}
			}
		}
		return canMove;
		break;
	case KEY_PRESS_RIGHT:
		for (int i = 0; i < getWorld()->getActors().size(); i++) {
			if (getWorld()->getActors()[i]->getID() == TID_BOULDER && getWorld()->getActors()[i]->isVisible()) {
				for (int j = 0; j < 4; j++) {
					for (int k = 0; k < 4; k++) {
						if (getX() + 4 == getWorld()->getActors()[i]->getX() && getY() + j == getWorld()->getActors()[i]->getY() + k) {
							canMove = false;
						}
					}
				}
			}
		}
		return canMove;
		break;
	case KEY_PRESS_UP:
		for (int i = 0; i < getWorld()->getActors().size(); i++) {
			if (getWorld()->getActors()[i]->getID() == TID_BOULDER && getWorld()->getActors()[i]->isVisible()) {
				for (int j = 0; j < 4; j++) {
					for (int k = 0; k < 4; k++) {
						if (getX() + j == getWorld()->getActors()[i]->getX() + k && getY() + 4 == getWorld()->getActors()[i]->getY()) {
							canMove = false;
						}
					}
				}
			}
		}
		return canMove;
		break;
	case KEY_PRESS_DOWN:
		for (int i = 0; i < getWorld()->getActors().size(); i++) {
			if (getWorld()->getActors()[i]->getID() == TID_BOULDER && getWorld()->getActors()[i]->isVisible()) {
				for (int j = 0; j < 4; j++) {
					for (int k = 0; k < 4; k++) {
						if (getX() + j == getWorld()->getActors()[i]->getX() + k && getY() == getWorld()->getActors()[i]->getY() + 4) {
							canMove = false;
						}
					}
				}
			}
		}
		return canMove;
		break;
	default:
		return false;
		break;
	}
}

void TunnelMan::increaseInven(type item) {
	switch (item) {
	case gold:
		getWorld()->tGold++;
		break;
	case sonar:
		getWorld()->tSonar ++;
		break;
	case squirt:
		getWorld()->remainingWater += 5;
		break;
	}
}

void Boulder::doSomething() {
	//doSomething boulder call
	//checks if the boulder is alive to make sure behavior cant be looped by a dead boulder
	//calls to the okDrop function which constantly checks if there is a 4x1 'hole' of 'empty' earth that the boulder can fall through
	//directly under it
	//if this ever returns true the boulder immediately enters a waiting state and stores the tick this triggered at in a member int
	//when the incrementing tick counter in student world reaches the stored tick value + 30 the boulder transitions its falling state bool to true
	//when this happens, every tick the boulder checks if its still falling and okDrop still returns true
	//if okDrop returns false, a bool fall is set to false, the boulder is marked as fell, and it is set to dead
	//the next tick after this it is set to invisible
	if (!alive()) {
		return;
	}

	if (getWorld()->okDrop(this) && !waiting && !falling) {
		wait(true);
		myTick = getWorld()->tickCount;

	}

	if (waiting && myTick + 30 == getWorld()->tickCount) {
		getWorld()->playSound(SOUND_FALLING_ROCK);
		wait(false);

		fall(true);
	}

	if (falling) {
		if (getWorld()->okDrop(this)) {
			moveTo(getX(), getY() - 1);

			bool hitTman = false;

			bool hitProtester = false;

			if (sqrt((pow(getWorld()->getMan()->getX() - getX(), 2.0) + pow(getWorld()->getMan()->getY() - getY(), 2.0))) <= 3) {
				if (!getWorld()->getMan()->touched) {
					hitTman = true;
					getWorld()->getMan()->touched = true;
				}
			}

			for (int i = 0; i < getWorld()->getActors().size(); i++) {
				if (getWorld()->getActors()[i]->getID() == TID_PROTESTER || getWorld()->getActors()[i]->getID() == TID_HARD_CORE_PROTESTER) {

					if (sqrt((pow(getWorld()->getActors()[i]->getX() - getX(), 2.0) + pow(getWorld()->getActors()[i]->getY() - getY(), 2.0))) <= 3) {
						if (!getWorld()->getActors()[i]->annoyed && !getWorld()->getActors()[i]->leaving && !getWorld()->getActors()[i]->stunned) {
							getWorld()->getActors()[i]->annoy(100);
							getWorld()->increaseScore(500);
						}
					}
				}

			}

			if (hitTman) {
				getWorld()->getMan()->setDead();
				getWorld()->getMan()->annoy(getWorld()->getMan()->hp);
				getWorld()->kia = true;
			}
		}
		else {
			fall(false);
			setDead();
			fell = true;
		}
	}
}

void Boulder::wait(bool state) {
	waiting = true;
}

void Boulder::fall(bool state) {
	falling = true;
}

void Squirt::doSomething() {
	if (!alive()) {
		return;
	}

	//spawning and collision checks performed in auxillary functions here and in studentworld
	movement();

	bool touchedn = false;

	bool touchedh = false;

	for (int i = 0; i < getWorld()->getActors().size(); i++) {
		if (getWorld()->getActors()[i]->getID() == TID_PROTESTER || getWorld()->getActors()[i]->getID() == TID_HARD_CORE_PROTESTER) {

			if (sqrt((pow(getWorld()->getActors()[i]->getX() - getX(), 2.0) + pow(getWorld()->getActors()[i]->getY() - getY(), 2.0))) <= 3) {
				if (getWorld()->getActors()[i]->alive() && !getWorld()->getActors()[i]->leaving) {
					if (getWorld()->getActors()[i]->getID() == TID_PROTESTER) {
						touchedn = true;
					}
					else {
						touchedh = true;
					}
				}
			}
		}


		if (!getWorld()->getActors()[i]->stare && !getWorld()->getActors()[i]->stunned && touchedn) {
			getWorld()->getActors()[i]->annoy(2);
			if (getWorld()->getActors()[i]->hp == 0) {
				getWorld()->increaseScore(100);
			}
			getWorld()->getActors()[i]->annoyed = true;
			setDead();
			return;
		}
		touchedn = false;

		if (!getWorld()->getActors()[i]->stare && !getWorld()->getActors()[i]->stunned && touchedh) {
			getWorld()->getActors()[i]->annoy(2);
			if (getWorld()->getActors()[i]->hp == 0) {
				getWorld()->increaseScore(250);
			}
			getWorld()->getActors()[i]->annoyed = true;
			setDead();
			return;
		}
		touchedh = false;


		//earth collision
		if (getWorld()->water_collision(this)) {
			setDead();
			return;
		}

		//boulder collision
		if (getWorld()->getActors()[i]->getID() == TID_BOULDER) {

			for (int j = 0; j < 3; j++) {
				for (int k = 0; k < 3; k++) {

					for (int l = 0; l < 3; l++) {
						for (int m = 0; m < 3; m++) {
							if (getX() + j == getWorld()->getActors()[i]->getX() + l && getY() + k == getWorld()->getActors()[i]->getY() + m) {
								setDead();
								return;
							}
						}
					}

				}
			}
		}

	}
}

void Squirt::movement() {
	switch (getDirection())
	{
	case left:
		if (getX() == initX - 4) {
			setDead();
		}

		if (getX() - 1 > 0) {
			moveTo(getX() - 1, getY());
		}
		else {
			setDead();
		}
		break;
	case right:
		if (getX() == initX + 4) {
			setDead();
		}

		if (getX() + 1 < 64) {
			moveTo(getX() + 1, getY());
		}
		else {
			setDead();
		}
		break;
	case up:
		if (getY() == initY + 4) {
			setDead();
		}

		if (getY() + 1 < 64) {
			moveTo(getX(), getY() + 1);
		}
		else {
			setDead();
		}
		break;
	case down:
		if (getY() == initY - 4) {
			setDead();
		}

		if (getY() - 1 > 0) {
			moveTo(getX(), getY() - 1);
		}
		else {
			setDead();
		}
		break;
	default:
		return;
		break;
	}
}

void Barrel::doSomething() {
	if (!alive()) {
		return;
	}

	int outcome = getWorld()->goodie_collision(this);

	if (outcome == 1) {
		setDead();
		getWorld()->levelOil--;
		getWorld()->increaseScore(1000);
		getWorld()->playSound(SOUND_FOUND_OIL);
	}
	else if (outcome == 2) {
		setVisible(true);
	}

}

void GoldNugget::doSomething() {
	if (!alive()) {
		return;
	}

	if (gState == false) {
		int outcome = getWorld()->goodie_collision(this);

		if (outcome == 1) {
			setDead();
			getWorld()->fieldGold--;
			getWorld()->getMan()->increaseInven(gold);
			getWorld()->increaseScore(10);
			getWorld()->playSound(SOUND_GOT_GOODIE);
		}
		else if (outcome == 2) {
			setVisible(true);
		}
	}
	else {

		for (int i = 0; i < getWorld()->getActors().size(); i++) {
			if (getWorld()->getActors()[i]->getID() == TID_PROTESTER || getWorld()->getActors()[i]->getID() == TID_HARD_CORE_PROTESTER) {

				if (sqrt((pow(getWorld()->getActors()[i]->getX() - getX(), 2.0) + pow(getWorld()->getActors()[i]->getY() - getY(), 2.0))) <= 3) {
					if (!getWorld()->getActors()[i]->stare && !getWorld()->getActors()[i]->stunned) {
						getWorld()->getActors()[i]->bribed = true;
						setDead();
					}
				}
			}

		}

		if (myTick + 100 == getWorld()->tickCount) {
			setDead();
		}
	}
}

void SonarKit::doSomething() {
	if (!alive()) {
		return;
	}

	int outcome = getWorld()->goodie_collision(this);

	if (outcome == 1) {
		setDead();
		getWorld()->fieldSonar--;
		getWorld()->getMan()->increaseInven(sonar);
		getWorld()->increaseScore(75);
		getWorld()->playSound(SOUND_GOT_GOODIE);
	}

	if (myTick + getWorld()->itemLife == getWorld()->tickCount) {
		setDead();
	}
}

void WaterPool::doSomething() {
	if (!alive()) {
		return;
	}

	int outcome = getWorld()->goodie_collision(this);

	if (outcome == 1) {
		setDead();
		getWorld()->getMan()->increaseInven(squirt);
		getWorld()->increaseScore(100);
		getWorld()->playSound(SOUND_GOT_GOODIE);
	}

	if (myTick + getWorld()->itemLife == getWorld()->tickCount) {
		setDead();
	}
}

void Protester::doSomething() {
	if (getID() == TID_PROTESTER) {
		//behavior 1
		if (!alive()) {
			return;
		}

		if (getWorld()->ticksToWaitBetweenMoves > 0) {
			//behavior 2
			if (resting) {
				if (myTick + getWorld()->ticksToWaitBetweenMoves == getWorld()->tickCount) {
					resting = false;
				}
				else {
					return;
				}
			}
		}

		if (hp == 0 && !leaving) {
			getWorld()->playSound(SOUND_PROTESTER_GIVE_UP);
			leaving = true;
			myTick = 0;
			resting = false;
			stunned = false;
			freezeTick = 0;
			intersected = false;
			sTick = 0;
			yelled = false;
			yellTick = 0;

			myMap[getY()][getX()] = 1;
			Point next(getX(), getY());
			path.push(next);
		}

		if (annoyed && !leaving && !stunned) {
			getWorld()->playSound(SOUND_PROTESTER_ANNOYED);
			stunned = true;
			freezeTick = 0;
			annoyed = false;
		}

		getBribed();

		if (!leaving) {

			if (stunned) {
				freezeTick++;
			}

			if (yelled) {
				yellTick++;
			}

			if (intersected) {
				sTick++;
			}

			if (stunned && freezeTick == getWorld()->stunTick) {
				stunned = false;
				freezeTick = 0;
			}

			if (intersected && sTick == 200) {
				intersected = false;
				sTick = 0;
			}

			if (yelled && yellTick == 15) {
				yelled = false;
				yellTick = 0;
			}

			if (!stunned) {
				//behavior 4
				switch (getDirection()) {
				case up:
					if (sqrt((pow(getWorld()->getMan()->getX() - getX(), 2.0) + pow(getWorld()->getMan()->getY() - getY(), 2.0))) <= 4 && getWorld()->getMan()->getY() > getY()) {
						if (!yelled && yellTick == 0) {
							getWorld()->playSound(SOUND_PROTESTER_YELL);
							getWorld()->getMan()->annoy(2);
							if (getWorld()->getMan()->hp == 0) {
								getWorld()->kia = true;
							}
							yelled = true;
						}
						myTick = getWorld()->tickCount;
						resting = true;
						return;
					}
					break;
				case down:
					if (sqrt((pow(getWorld()->getMan()->getX() - getX(), 2.0) + pow(getWorld()->getMan()->getY() - getY(), 2.0))) <= 4 && getWorld()->getMan()->getY() < getY()) {
						if (!yelled && yellTick == 0) {
							getWorld()->playSound(SOUND_PROTESTER_YELL);
							getWorld()->getMan()->annoy(2);
							if (getWorld()->getMan()->hp == 0) {
								getWorld()->kia = true;
							}
							yelled = true;
						}
						myTick = getWorld()->tickCount;
						resting = true;
						return;
					}
					break;
				case left:
					if (sqrt((pow(getWorld()->getMan()->getX() - getX(), 2.0) + pow(getWorld()->getMan()->getY() - getY(), 2.0))) <= 4 && getWorld()->getMan()->getX() < getX()) {
						if (!yelled && yellTick == 0) {
							getWorld()->playSound(SOUND_PROTESTER_YELL);
							getWorld()->getMan()->annoy(2);
							if (getWorld()->getMan()->hp == 0) {
								getWorld()->kia = true;
							}
							yelled = true;
						}
						myTick = getWorld()->tickCount;
						resting = true;
						return;
					}
					break;
				case right:
					if (sqrt((pow(getWorld()->getMan()->getX() - getX(), 2.0) + pow(getWorld()->getMan()->getY() - getY(), 2.0))) <= 4 && getWorld()->getMan()->getX() > getX()) {
						if (!yelled && yellTick == 0) {
							getWorld()->playSound(SOUND_PROTESTER_YELL);
							getWorld()->getMan()->annoy(2);
							if (getWorld()->getMan()->hp == 0) {
								getWorld()->kia = true;
							}
							yelled = true;
						}
						myTick = getWorld()->tickCount;
						resting = true;
						return;
					}
					break;
				}
				//end behavior 4

				//behavior 5
				Direction search = getWorld()->p_LoS(this);
				double tDist = sqrt((pow(getWorld()->getMan()->getX() - getX(), 2.0) + pow(getWorld()->getMan()->getY() - getY(), 2.0)));
				if (search != none && tDist > 4) {
					setDirection(search);

					switch (search) {
					case up:
						moveTo(getX(), getY() + 1);
						myTick = getWorld()->tickCount;
						newSteps();
						resting = true;
						return;
						break;
					case down:
						moveTo(getX(), getY() - 1);
						myTick = getWorld()->tickCount;
						newSteps();
						resting = true;
						return;
						break;
					case left:
						moveTo(getX() - 1, getY());
						myTick = getWorld()->tickCount;
						newSteps();
						resting = true;
						return;
						break;
					case right:
						moveTo(getX() + 1, getY());
						myTick = getWorld()->tickCount;
						newSteps();
						resting = true;
						return;
						break;
					}
					numSquaresToMoveInCurrentDirection = 0;
				}
				//end behavior 5
				else {
					//behavior 6, 8, 9
					if (numSquaresToMoveInCurrentDirection != 0) {
						switch (getDirection()) {
						case left:
							if (getX() - 1 >= 0 && getWorld()->p_moveCheck(this, left)) {
								moveTo(getX() - 1, getY());
								numSquaresToMoveInCurrentDirection--;
								myTick = getWorld()->tickCount;
								resting = true;
							}
							else {
								numSquaresToMoveInCurrentDirection = 0;
								myTick = getWorld()->tickCount;
								resting = true;
							}
							break;
						case right:
							if (getX() + 1 <= 60 && getWorld()->p_moveCheck(this, right)) {
								moveTo(getX() + 1, getY());
								numSquaresToMoveInCurrentDirection--;
								myTick = getWorld()->tickCount;
								resting = true;
							}
							else {
								numSquaresToMoveInCurrentDirection = 0;
								myTick = getWorld()->tickCount;
								resting = true;
							}
							break;
						case up:
							if (getY() + 1 <= 60 && getWorld()->p_moveCheck(this, up)) {
								moveTo(getX(), getY() + 1);
								numSquaresToMoveInCurrentDirection--;
								myTick = getWorld()->tickCount;
								resting = true;
							}
							else {
								numSquaresToMoveInCurrentDirection = 0;
								myTick = getWorld()->tickCount;
								resting = true;
							}
							break;
						case down:
							if (getY() - 1 >= 0 && getWorld()->p_moveCheck(this, down)) {
								moveTo(getX(), getY() - 1);
								numSquaresToMoveInCurrentDirection--;
								myTick = getWorld()->tickCount;
								resting = true;
							}
							else {
								numSquaresToMoveInCurrentDirection = 0;
								myTick = getWorld()->tickCount;
								resting = true;
							}
							break;
						}
					}
					else if (numSquaresToMoveInCurrentDirection == 0) {
						int randDir = rand() % (4 - 1 + 1) + 1;

						bool good = false;

						while (!good) {

							bool pass = true;

							switch (randDir) {
							case 1:
								if (!getWorld()->p_moveCheck(this, up)) {
									pass = false;
								}
								break;
							case 2:
								if (!getWorld()->p_moveCheck(this, down)) {
									pass = false;
								}
								break;
							case 3:
								if (!getWorld()->p_moveCheck(this, left)) {
									pass = false;
								}
								break;
							case 4:
								if (!getWorld()->p_moveCheck(this, right)) {
									pass = false;
								}
								break;
							}

							if (pass) {
								good = true;
							}
							else {
								randDir = rand() % (4 - 1 + 1) + 1;
							}
						}

						switch (randDir) {
						case 1:
							setDirection(up);
							break;
						case 2:
							setDirection(down);
							break;
						case 3:
							setDirection(left);
							break;
						case 4:
							setDirection(right);
							break;
						}
						newSteps();
					}
					//end behavior 6, 8, 9

					//behavior 7
					Direction inter = intersection();
					if (inter != none && !intersected && sTick == 0) {
						if (!intersected && sTick == 0) {

							switch (inter) {
							case up:
								moveTo(getX(), getY() + 1);
								break;
							case down:
								moveTo(getX(), getY() - 1);
								break;
							case left:
								moveTo(getX() - 1, getY());
								break;
							case right:
								moveTo(getX() + 1, getY());
								break;
							}
							intersected = true;
						}
					}

				}
			}
		}
		if (leaving && getX() == 60 && getY() == 60) {
			getWorld()->fieldProt--;
			setDead();
		}

		if (!embark && leaving) {
			leaveField();
		}
		else if (leaving && embark) {
			realLeave();
			myTick = getWorld()->tickCount;
			resting = true;
		}
		//behavior 3
	}
}

void RegularProtester::getBribed() {
	if (bribed && !leaving) {
		getWorld()->playSound(SOUND_PROTESTER_FOUND_GOLD);
		getWorld()->increaseScore(25);
		leaving = true;
		myTick = 0;
		bribed = false;

		myMap[getY()][getX()] = 1;
		Point next(getX(), getY());
		path.push(next);
	}
}

void Protester::newSteps() {
	numSquaresToMoveInCurrentDirection = rand() % (60 - 8 + 1) + 8;
}

baseClass::Direction Protester::intersection() {
	switch (getDirection()) {
	case up:
	case down:
		if (getWorld()->p_moveCheck(this, left)) {
			if (getWorld()->p_moveCheck(this, right)) {
				int choice = rand() % 1;
				if (choice == 0) {
					return left;
				}
				else {
					return right;
				}
			}
		}
		else if (getWorld()->p_moveCheck(this, right)) {
			return right;
		}
		else {
			return none;
		}
		break;
	case left:
	case right:
		if (getWorld()->p_moveCheck(this, up)) {
			if (getWorld()->p_moveCheck(this, down)) {
				int choice = rand() % 1;
				if (choice == 0) {
					return up;
				}
				else {
					return down;
				}
			}
		}
		else if (getWorld()->p_moveCheck(this, down)) {
			return down;
		}
		else {
			return none;
		}
		break;
	default:
		return none;
		break;
	}
	return none;
}

void Protester::leaveField() {
	//cout << "called\n";
	while (!path.empty()) {
		Point cur = path.front();

		path.pop();

		if (cur.x == 60 && cur.y == 60) {
			//turning queue of steps into followable directions
			Point exit(cur.x, cur.y);
			exitPath.push(exit);

			while (myMap[exitPath.top().y][exitPath.top().x] != 1) {
				if (myMap[exitPath.top().y + 1][exitPath.top().x] == myMap[exitPath.top().y][exitPath.top().x] - 1) {

					Point next(exitPath.top().x, exitPath.top().y + 1);
					exitPath.push(next);
				}

				else if (myMap[exitPath.top().y][exitPath.top().x + 1] == myMap[exitPath.top().y][exitPath.top().x] - 1) {

					Point next(exitPath.top().x + 1, exitPath.top().y);
					exitPath.push(next);
				}

				else if (myMap[exitPath.top().y][exitPath.top().x - 1] == myMap[exitPath.top().y][exitPath.top().x] - 1) {

					Point next(exitPath.top().x - 1, exitPath.top().y);
					exitPath.push(next);
				}

				else if (myMap[exitPath.top().y - 1][exitPath.top().x] == myMap[exitPath.top().y][exitPath.top().x] - 1) {

					Point next(exitPath.top().x, exitPath.top().y - 1);
					exitPath.push(next);
				}
			}
			//cout << "solution found\n";
			embark = true;
			return;
		}

		if (getWorld()->leaveCheck(cur.x, cur.y, up) && myMap[cur.y + 1][cur.x] == -1) {

			Point next(cur.x, cur.y + 1);
			path.push(next);
			myMap[cur.y + 1][cur.x] = myMap[cur.y][cur.x] + 1;
		}

		if (getWorld()->leaveCheck(cur.x, cur.y, right) && myMap[cur.y][cur.x + 1] == -1) {

			Point next(cur.x + 1, cur.y);
			path.push(next);
			myMap[cur.y][cur.x + 1] = myMap[cur.y][cur.x] + 1;
		}

		if (getWorld()->leaveCheck(cur.x, cur.y, left) && myMap[cur.y][cur.x - 1] == -1) {

			Point next(cur.x - 1, cur.y);
			path.push(next);
			myMap[cur.y][cur.x - 1] = myMap[cur.y][cur.x] + 1;
		}

		if (getWorld()->leaveCheck(cur.x, cur.y, down) && myMap[cur.y - 1][cur.x] == -1) {

			Point next(cur.x, cur.y - 1);
			path.push(next);
			myMap[cur.y - 1][cur.x] = myMap[cur.y][cur.x] + 1;
		}
	}
}

void Protester::realLeave() {
	if (!exitPath.empty()) {
		if (exitPath.top().y > getY()) {
			setDirection(up);
		}
		else if (exitPath.top().y < getY()) {
			setDirection(down);
		}
		else if (exitPath.top().x < getX()) {
			setDirection(left);
		}
		else if (exitPath.top().x > getX()) {
			setDirection(right);
		}
		moveTo(exitPath.top().x, exitPath.top().y);
		exitPath.pop();
	}
}

void RegularProtester::doSomething() {
	Protester::doSomething();
}

void HardcoreProtester::doSomething() {
	//behavior 1
	if (!alive()) {
		return;
	}

	if (getWorld()->ticksToWaitBetweenMoves > 0) {
		//behavior 2
		if (resting) {
			if (myTick + getWorld()->ticksToWaitBetweenMoves == getWorld()->tickCount) {
				resting = false;
			}
			else {
				return;
			}
		}
	}


	if (hp == 0 && !leaving) {
		getWorld()->playSound(SOUND_PROTESTER_GIVE_UP);
		leaving = true;
		myTick = 0;
		resting = false;
		stare = false;
		stareTick = 0;
		stunned = false;
		freezeTick = 0;
		intersected = false;
		sTick = 0;
		yelled = false;
		yellTick = 0;

		myMap[getY()][getX()] = 1;
		Point next(getX(), getY());
		path.push(next);
	}

	if (annoyed && !leaving) {
		getWorld()->playSound(SOUND_PROTESTER_ANNOYED);
		stunned = true;
		freezeTick = 0;
		annoyed = false;
	}

	getBribed();

	if (!leaving) {

		if (stare) {
			stareTick++;
		}

		if (stunned) {
			freezeTick++;
		}

		if (yelled) {
			yellTick++;
		}

		if (intersected) {
			sTick++;
		}

		if (stare && stareTick == getWorld()->stareTick) {
			stare = false;
			stareTick = 0;
		}

		if (stunned && freezeTick == getWorld()->stunTick) {
			stunned = false;
			freezeTick = 0;
		}

		if (intersected && sTick == 200) {
			intersected = false;
			sTick = 0;
		}

		if (yelled && yellTick == 15) {
			yelled = false;
			yellTick = 0;
		}

		if (!stunned && !stare) {
			//behavior 4
			switch (getDirection()) {
			case up:
				if (sqrt((pow(getWorld()->getMan()->getX() - getX(), 2.0) + pow(getWorld()->getMan()->getY() - getY(), 2.0))) <= 4 && getWorld()->getMan()->getY() > getY()) {
					if (!yelled && yellTick == 0) {
						getWorld()->playSound(SOUND_PROTESTER_YELL);
						getWorld()->getMan()->annoy(2);
						if (getWorld()->getMan()->hp == 0) {
							getWorld()->kia = true;
						}
						yelled = true;
					}
					myTick = getWorld()->tickCount;
					resting = true;
					return;
				}
				break;
			case down:
				if (sqrt((pow(getWorld()->getMan()->getX() - getX(), 2.0) + pow(getWorld()->getMan()->getY() - getY(), 2.0))) <= 4 && getWorld()->getMan()->getY() < getY()) {
					if (!yelled && yellTick == 0) {
						getWorld()->playSound(SOUND_PROTESTER_YELL);
						getWorld()->getMan()->annoy(2);
						if (getWorld()->getMan()->hp == 0) {
							getWorld()->kia = true;
						}
						yelled = true;
					}
					myTick = getWorld()->tickCount;
					resting = true;
					return;
				}
				break;
			case left:
				if (sqrt((pow(getWorld()->getMan()->getX() - getX(), 2.0) + pow(getWorld()->getMan()->getY() - getY(), 2.0))) <= 4 && getWorld()->getMan()->getX() < getX()) {
					if (!yelled && yellTick == 0) {
						getWorld()->playSound(SOUND_PROTESTER_YELL);
						getWorld()->getMan()->annoy(2);
						if (getWorld()->getMan()->hp == 0) {
							getWorld()->kia = true;
						}
						yelled = true;
					}
					myTick = getWorld()->tickCount;
					resting = true;
					return;
				}
				break;
			case right:
				if (sqrt((pow(getWorld()->getMan()->getX() - getX(), 2.0) + pow(getWorld()->getMan()->getY() - getY(), 2.0))) <= 4 && getWorld()->getMan()->getX() > getX()) {
					if (!yelled && yellTick == 0) {
						getWorld()->playSound(SOUND_PROTESTER_YELL);
						getWorld()->getMan()->annoy(2);
						if (getWorld()->getMan()->hp == 0) {
							getWorld()->kia = true;
						}
						yelled = true;
					}
					myTick = getWorld()->tickCount;
					resting = true;
					return;
				}
				break;
			}
			//end behavior 4

			//unique hardcore protester behavior - cell phone tracking
			if (sqrt((pow(getX() - getWorld()->getMan()->getX(), 2.0) + pow(getY() - getWorld()->getMan()->getY(), 2.0))) > 4) {
				int movesAway = 16 + getWorld()->getLevel() * 2;

				//clearing the map, stack, and queue to recalculate based on the current position of tunnelman
				for (int i = 0; i < 64; i++) {
					for (int j = 0; j < 64; j++) {
						trackMap[i][j] = -1;
					}
				}

				while (!track_queue.empty()) {
					track_queue.pop();
				}

				while (!trackStack.empty()) {
					trackStack.pop();
				}

				Point next(getX(), getY());
				track_queue.push(next);
				trackMap[getY()][getX()] = 1;

				if (stepsAway() <= movesAway) {
					if (!trackStack.empty()) {

						if (trackStack.top().x == getX() && trackStack.top().y == getY()) {
							trackStack.pop();
						}

						if (trackStack.top().y > getY()) {
							setDirection(up);
						}
						else if (trackStack.top().y < getY()) {
							setDirection(down);
						}
						else if (trackStack.top().x < getX()) {
							setDirection(left);
						}
						else if (trackStack.top().x > getX()) {
							setDirection(right);
						}
						moveTo(trackStack.top().x, trackStack.top().y);
						trackStack.pop();
						myTick = getWorld()->tickCount;
						resting = true;
						return;
					}
				}
			}

			//behavior 5
			Direction search = getWorld()->p_LoS(this);
			double tDist = sqrt((pow(getWorld()->getMan()->getX() - getX(), 2.0) + pow(getWorld()->getMan()->getY() - getY(), 2.0)));
			if (search != none && tDist > 4) {
				setDirection(search);

				switch (search) {
				case up:
					moveTo(getX(), getY() + 1);
					myTick = getWorld()->tickCount;
					newSteps();
					resting = true;
					return;
					break;
				case down:
					moveTo(getX(), getY() - 1);
					myTick = getWorld()->tickCount;
					newSteps();
					resting = true;
					return;
					break;
				case left:
					moveTo(getX() - 1, getY());
					myTick = getWorld()->tickCount;
					newSteps();
					resting = true;
					return;
					break;
				case right:
					moveTo(getX() + 1, getY());
					myTick = getWorld()->tickCount;
					newSteps();
					resting = true;
					return;
					break;
				}
				numSquaresToMoveInCurrentDirection = 0;
			}
			//end behavior 5
			else {
				//behavior 6, 8, 9
				if (numSquaresToMoveInCurrentDirection != 0) {
					switch (getDirection()) {
					case left:
						if (getX() - 1 >= 0 && getWorld()->p_moveCheck(this, left)) {
							moveTo(getX() - 1, getY());
							numSquaresToMoveInCurrentDirection--;
							myTick = getWorld()->tickCount;
							resting = true;
						}
						else {
							numSquaresToMoveInCurrentDirection = 0;
							myTick = getWorld()->tickCount;
							resting = true;
						}
						break;
					case right:
						if (getX() + 1 <= 60 && getWorld()->p_moveCheck(this, right)) {
							moveTo(getX() + 1, getY());
							numSquaresToMoveInCurrentDirection--;
							myTick = getWorld()->tickCount;
							resting = true;
						}
						else {
							numSquaresToMoveInCurrentDirection = 0;
							myTick = getWorld()->tickCount;
							resting = true;
						}
						break;
					case up:
						if (getY() + 1 <= 60 && getWorld()->p_moveCheck(this, up)) {
							moveTo(getX(), getY() + 1);
							numSquaresToMoveInCurrentDirection--;
							myTick = getWorld()->tickCount;
							resting = true;
						}
						else {
							numSquaresToMoveInCurrentDirection = 0;
							myTick = getWorld()->tickCount;
							resting = true;
						}
						break;
					case down:
						if (getY() - 1 >= 0 && getWorld()->p_moveCheck(this, down)) {
							moveTo(getX(), getY() - 1);
							numSquaresToMoveInCurrentDirection--;
							myTick = getWorld()->tickCount;
							resting = true;
						}
						else {
							numSquaresToMoveInCurrentDirection = 0;
							myTick = getWorld()->tickCount;
							resting = true;
						}
						break;
					}
				}
				else if (numSquaresToMoveInCurrentDirection == 0) {
					int randDir = rand() % (4 - 1 + 1) + 1;

					bool good = false;

					while (!good) {

						bool pass = true;

						switch (randDir) {
						case 1:
							if (!getWorld()->p_moveCheck(this, up)) {
								pass = false;
							}
							break;
						case 2:
							if (!getWorld()->p_moveCheck(this, down)) {
								pass = false;
							}
							break;
						case 3:
							if (!getWorld()->p_moveCheck(this, left)) {
								pass = false;
							}
							break;
						case 4:
							if (!getWorld()->p_moveCheck(this, right)) {
								pass = false;
							}
							break;
						}

						if (pass) {
							good = true;
						}
						else {
							randDir = rand() % (4 - 1 + 1) + 1;
						}
					}

					switch (randDir) {
					case 1:
						setDirection(up);
						break;
					case 2:
						setDirection(down);
						break;
					case 3:
						setDirection(left);
						break;
					case 4:
						setDirection(right);
						break;
					}
					newSteps();
				}
				//end behavior 6, 8, 9

				//behavior 7
				Direction inter = intersection();
				if (inter != none && !intersected && sTick == 0) {
					if (!intersected && sTick == 0) {

						switch (inter) {
						case up:
							moveTo(getX(), getY() + 1);
							break;
						case down:
							moveTo(getX(), getY() - 1);
							break;
						case left:
							moveTo(getX() - 1, getY());
							break;
						case right:
							moveTo(getX() + 1, getY());
							break;
						}
						intersected = true;
					}
				}

			}
		}
	}
	if (leaving && getX() == 60 && getY() == 60) {
		getWorld()->fieldProt--;
		setDead();
	}
	if (!embark) {
		leaveField();
	}
	else {
		realLeave();
		myTick = getWorld()->tickCount;
		resting = true;
	}
	//behavior 3
}

int HardcoreProtester::stepsAway() {
	while (!track_queue.empty()) {

		Point cur = track_queue.front();

		track_queue.pop();


		if (cur.x == getWorld()->getMan()->getX() && cur.y == getWorld()->getMan()->getY()) {

			Point exit(cur.x, cur.y);

			trackStack.push(exit);

			//cout << cur.x << ", " << cur.y << endl;

			while (trackMap[trackStack.top().y][trackStack.top().x] != 1) {
				if (trackMap[trackStack.top().y + 1][trackStack.top().x] == trackMap[trackStack.top().y][trackStack.top().x] - 1) {

					Point next(trackStack.top().x, trackStack.top().y + 1);
					trackStack.push(next);
				}

				else if (trackMap[trackStack.top().y][trackStack.top().x + 1] == trackMap[trackStack.top().y][trackStack.top().x] - 1) {

					Point next(trackStack.top().x + 1, trackStack.top().y);
					trackStack.push(next);
				}

				else if (trackMap[trackStack.top().y][trackStack.top().x - 1] == trackMap[trackStack.top().y][trackStack.top().x] - 1) {

					Point next(trackStack.top().x - 1, trackStack.top().y);
					trackStack.push(next);
				}

				else if (trackMap[trackStack.top().y - 1][trackStack.top().x] == trackMap[trackStack.top().y][trackStack.top().x] - 1) {

					Point next(trackStack.top().x, trackStack.top().y - 1);
					trackStack.push(next);
				}
				//cout << "stack works\n";
			}

			return trackStack.size();
		}

		if (getWorld()->leaveCheck(cur.x, cur.y, up) && trackMap[cur.y + 1][cur.x] == -1) {

			Point next(cur.x, cur.y + 1);
			track_queue.push(next);
			trackMap[cur.y + 1][cur.x] = trackMap[cur.y][cur.x] + 1;
		}

		if (getWorld()->leaveCheck(cur.x, cur.y, right) && trackMap[cur.y][cur.x + 1] == -1) {

			Point next(cur.x + 1, cur.y);
			track_queue.push(next);
			trackMap[cur.y][cur.x + 1] = trackMap[cur.y][cur.x] + 1;
		}

		if (getWorld()->leaveCheck(cur.x, cur.y, left) && trackMap[cur.y][cur.x - 1] == -1) {

			Point next(cur.x - 1, cur.y);
			track_queue.push(next);
			trackMap[cur.y][cur.x - 1] = trackMap[cur.y][cur.x] + 1;
		}

		if (getWorld()->leaveCheck(cur.x, cur.y, down) && trackMap[cur.y - 1][cur.x] == -1) {

			Point next(cur.x, cur.y - 1);
			track_queue.push(next);
			trackMap[cur.y - 1][cur.x] = trackMap[cur.y][cur.x] + 1;
		}
		//cout << "queue works\n";
	}
	//cout << "starting over ;-;\n";
}

void HardcoreProtester::getBribed() {
	if (bribed && !leaving) {
		getWorld()->playSound(SOUND_PROTESTER_FOUND_GOLD);
		getWorld()->increaseScore(50);

		stare = true;
		stareTick = 0;
		bribed = false;
	}
}